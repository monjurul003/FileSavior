/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mik.encryption;

/**
 *
 * @author monjurul.k
 */
public class Password_encryption {
    public static void main(String[] args){
        Blowfish bf = new Blowfish("@&12X3abc#");
        String str = bf.encryptString("asd123");
        System.out.println("Encrypted password-- "+str);

        System.out.println("Decrypted password-- "+bf.decryptString("c8af08f2a5681bba8aa5a63ef6be864e9b92afb09dd2f24f"));
    }
}
