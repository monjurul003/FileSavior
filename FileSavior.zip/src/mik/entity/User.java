/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package mik.entity;

import java.util.Date;

/**
 *
 * @author Daffodil PC
 */
public class User {
    
    private String userName;
    private String password; 
    private Date creationDate;
    private Date lastModifiedDate;
    
    
    public User(String userName, String password, Date creationDate) {
        this.userName = userName;
        this.password = password;
        this.creationDate = creationDate;
    }
    
    

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    
    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }
    
    
}
